package io.legado.app.data.entities

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class AdvancedTtsConfig(
    var id: String = System.currentTimeMillis().toString(),
    var name: String = "我的WS流式引擎",
    var interval: Int = 200,                       // 段落间隔(毫秒)
    var concurrentRate: Int = 1,                   // 并发率
    var jsLib: String = "",                        // 公共jsLib
    
    // ---- 前置请求链 (支持多步) ----
    var preSteps: List<PreStep> = listOf(PreStep()),
    
    // ---- WebSocket 主连接 ----
    var wsUrlTemplate: String = "wss://your-server.com/ws?token={{token}}",
    var sendScript: String = """connection.send(JSON.stringify({action:'synthesis', text: speakText, voice:'zh-CN-XiaoxiaoNeural'}))""",
    
    // ---- 返回解析 ----
    var parseMode: Int = 5,                        // 1=带头MP3, 2=PCM裸流, 3=JSON内嵌Base64, 4=纯Base64, 5=自定义JS
    var pcmSampleRate: Int = 16000,               // parseMode=2时有效
    var pcmChannel: Int = 1,                      // parseMode=2时有效
    var customParseScript: String = """
        try {
            const msg = JSON.parse(event.data);
            if (msg.type === 'audio') outputAudio(base64ToArrayBuffer(msg.data));
            if (msg.type === 'end') closeConnection();
        } catch(e) { outputAudio(event.data); }
    """.trimIndent(),
    var closeScript: String = ""                   // 断开收尾指令
) : Parcelable

@Parcelize
data class PreStep(
    var method: String = "POST",                   // GET / POST
    var url: String = "https://api.example.com/auth",
    var headers: String = "Content-Type: application/json",
    var body: String = "{\"key\":\"your_key\"}",
    var parseJs: String = """global.set('token', JSON.parse(responseBody).data.token);"""
) : Parcelable