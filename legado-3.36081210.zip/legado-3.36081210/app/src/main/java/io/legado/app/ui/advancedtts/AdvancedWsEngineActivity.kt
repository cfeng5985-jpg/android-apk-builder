package io.legado.app.ui.advancedtts

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast // 关键：原生 Toast 导入
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import io.legado.app.R
import io.legado.app.data.AdvancedTtsRepository
import io.legado.app.data.entities.AdvancedTtsConfig
import io.legado.app.data.entities.PreStep

class AdvancedWsEngineActivity : AppCompatActivity() {

    private lateinit var etName: TextInputEditText
    private lateinit var etInterval: TextInputEditText
    private lateinit var etConcurrent: TextInputEditText
    private lateinit var spinnerMethod1: Spinner
    private lateinit var etUrl1: TextInputEditText
    private lateinit var etHeaders1: TextInputEditText
    private lateinit var etBody1: TextInputEditText
    private lateinit var etParse1: TextInputEditText
    private lateinit var etWsUrl: TextInputEditText
    private lateinit var etSendScript: TextInputEditText
    private lateinit var spinnerParseMode: Spinner
    private lateinit var etCustomParse: TextInputEditText
    private lateinit var etCloseScript: TextInputEditText
    private lateinit var etJsLib: TextInputEditText
    private lateinit var btnSave: MaterialButton

    private var configId: String? = null
    private val repository: AdvancedTtsRepository by lazy { AdvancedTtsRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_advanced_ws_engine)

        initViews()
        setupSpinners()
        loadConfigIfEdit()
        btnSave.setOnClickListener { saveConfig() }
    }

    private fun initViews() {
        etName = findViewById(R.id.et_engine_name)
        etInterval = findViewById(R.id.et_interval)
        etConcurrent = findViewById(R.id.et_concurrent)
        spinnerMethod1 = findViewById(R.id.spinner_method_1)
        etUrl1 = findViewById(R.id.et_url_1)
        etHeaders1 = findViewById(R.id.et_headers_1)
        etBody1 = findViewById(R.id.et_body_1)
        etParse1 = findViewById(R.id.et_parse_1)
        etWsUrl = findViewById(R.id.et_ws_url)
        etSendScript = findViewById(R.id.et_send_script)
        spinnerParseMode = findViewById(R.id.spinner_parse_mode)
        etCustomParse = findViewById(R.id.et_custom_parse)
        etCloseScript = findViewById(R.id.et_close_script)
        etJsLib = findViewById(R.id.et_jslib)
        btnSave = findViewById(R.id.btn_save_engine)
    }

    private fun setupSpinners() {
        val methodAdapter = ArrayAdapter.createFromResource(
            this,
            R.array.request_methods,
            android.R.layout.simple_spinner_item
        )
        methodAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMethod1.adapter = methodAdapter

        val parseAdapter = ArrayAdapter.createFromResource(
            this,
            R.array.parse_modes,
            android.R.layout.simple_spinner_item
        )
        parseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerParseMode.adapter = parseAdapter
    }

    private fun loadConfigIfEdit() {
        configId = intent.getStringExtra("config_id")
        if (configId != null) {
            val config = repository.getConfigById(configId!!)
            if (config != null) {
                etName.setText(config.name)
                etInterval.setText(config.interval.toString())
                etConcurrent.setText(config.concurrentRate.toString())
                val methodPosition = if (config.preSteps.isNotEmpty()) {
                    listOf("GET", "POST").indexOf(config.preSteps[0].method).takeIf { it >= 0 } ?: 0
                } else 0
                spinnerMethod1.setSelection(methodPosition)
                if (config.preSteps.isNotEmpty()) {
                    etUrl1.setText(config.preSteps[0].url)
                    etHeaders1.setText(config.preSteps[0].headers)
                    etBody1.setText(config.preSteps[0].body)
                    etParse1.setText(config.preSteps[0].parseJs)
                }
                etWsUrl.setText(config.wsUrlTemplate)
                etSendScript.setText(config.sendScript)
                spinnerParseMode.setSelection((config.parseMode - 1).coerceIn(0, 4))
                etCustomParse.setText(config.customParseScript)
                etCloseScript.setText(config.closeScript)
                etJsLib.setText(config.jsLib)
            }
        }
    }

    private fun saveConfig() {
        val name = etName.text.toString().trim().ifEmpty { "未命名引擎" }
        val interval = etInterval.text.toString().toIntOrNull() ?: 200
        val concurrent = etConcurrent.text.toString().toIntOrNull() ?: 1

        val step1 = PreStep(
            method = spinnerMethod1.selectedItem.toString(),
            url = etUrl1.text.toString().trim(),
            headers = etHeaders1.text.toString().trim(),
            body = etBody1.text.toString().trim(),
            parseJs = etParse1.text.toString().trim()
        )

        val config = AdvancedTtsConfig(
            id = configId ?: System.currentTimeMillis().toString(),
            name = name,
            interval = interval,
            concurrentRate = concurrent,
            preSteps = listOf(step1),
            wsUrlTemplate = etWsUrl.text.toString().trim(),
            sendScript = etSendScript.text.toString().trim(),
            parseMode = spinnerParseMode.selectedItemPosition + 1,
            customParseScript = etCustomParse.text.toString().trim(),
            closeScript = etCloseScript.text.toString().trim(),
            jsLib = etJsLib.text.toString().trim()
        )

        repository.saveConfig(config)
        // 关键：用 Android 原生 Toast 写法，彻底避开之前那个 "private var toast" 的幽灵报错
        Toast.makeText(this, "✅ 引擎已保存：${config.name}", Toast.LENGTH_SHORT).show()
        finish()
    }
}