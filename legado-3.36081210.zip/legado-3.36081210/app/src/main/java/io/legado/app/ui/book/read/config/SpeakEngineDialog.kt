package io.legado.app.ui.book.read.config
import android.content.Context
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import io.legado.app.R
import io.legado.app.base.BaseDialogFragment
import io.legado.app.base.adapter.ItemViewHolder
import io.legado.app.base.adapter.RecyclerAdapter
import io.legado.app.constant.AppLog
import io.legado.app.data.appDb
import io.legado.app.data.entities.AdvancedTtsConfig
import io.legado.app.data.entities.HttpTTS
import io.legado.app.databinding.DialogEditTextBinding
import io.legado.app.databinding.DialogRecyclerViewBinding
import io.legado.app.databinding.ItemHttpTtsBinding
import io.legado.app.help.DirectLinkUpload
import io.legado.app.help.SourceSharePassphrase
import io.legado.app.help.config.AppConfig
import io.legado.app.help.source.clearSharedGlobalState
import io.legado.app.lib.dialogs.SelectItem
import io.legado.app.lib.dialogs.alert
import io.legado.app.lib.dialogs.sourceSharePassphraseButton
import io.legado.app.lib.theme.primaryColor
import io.legado.app.model.ReadAloud
import io.legado.app.model.ReadBook
import io.legado.app.ui.advancedtts.AdvancedWsEngineActivity
import io.legado.app.ui.association.ImportHttpTtsDialog
import io.legado.app.ui.file.HandleFileContract
import io.legado.app.ui.login.SourceLoginActivity
import io.legado.app.utils.ACache
import io.legado.app.utils.FileUtils
import io.legado.app.utils.GSON
import io.legado.app.utils.applyTint
import io.legado.app.utils.fromJsonObject
import io.legado.app.utils.gone
import io.legado.app.utils.isAbsUrl
import io.legado.app.utils.isJsonObject
import io.legado.app.utils.sendToClip
import io.legado.app.utils.setEdgeEffectColor
import io.legado.app.utils.setLayout
import io.legado.app.utils.showDialogFragment
import io.legado.app.utils.splitNotBlank
import io.legado.app.utils.startActivity
import io.legado.app.utils.toastOnUi
import io.legado.app.utils.viewbindingdelegate.viewBinding
import io.legado.app.utils.visible
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import java.io.File

private const val WS_ENGINE_PREFIX = "ws_"

internal fun HttpTTS.hasLoginCapability(): Boolean = !loginUrl.isNullOrBlank() || !loginUi.isNullOrBlank()
internal fun HttpTTS.shouldOpenLoginOnSelection(): Boolean = hasLoginCapability()

class SpeakEngineDialog : BaseDialogFragment(R.layout.dialog_recycler_view), Toolbar.OnMenuItemClickListener {
    private val binding by viewBinding(DialogRecyclerViewBinding::bind)
    private val viewModel: SpeakEngineViewModel by viewModels()
    private val ttsUrlKey = "ttsUrlKey"
    private val adapter by lazy { Adapter(requireContext()) }
    private var ttsEngine: String? = ReadAloud.ttsEngine
    private val sysTtsViews = arrayListOf<RadioButton>()
    private var currentSelect = -1
    private val callBack: CallBack? get() = parentFragment as? CallBack

    private val importDocResult = registerForActivityResult(HandleFileContract()) {
        it.uri?.let { uri -> showDialogFragment(ImportHttpTtsDialog(uri.toString())) }
    }

    private val exportDirResult = registerForActivityResult(HandleFileContract()) {
        it.uri?.let { uri ->
            val url = uri.toString()
            alert(R.string.export_success) {
                if (url.isAbsUrl()) {
                    setMessage(DirectLinkUpload.getSummary())
                    sourceSharePassphraseButton(layoutInflater, url, SourceSharePassphrase.Type.TTS_RULE)
                }
                val alertBinding = DialogEditTextBinding.inflate(layoutInflater).apply {
                    editView.hint = getString(R.string.path)
                    editView.setText(url)
                }
                customView { alertBinding.root }
                okButton { requireContext().sendToClip(url) }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        setLayout(ViewGroup.LayoutParams.MATCH_PARENT, 0.9f)
    }

    override fun onFragmentCreated(view: View, savedInstanceState: Bundle?) {
        initView()
        initMenu()
        initData()
    }

    private fun initView() = binding.run {
        toolBar.setBackgroundColor(primaryColor)
        toolBar.setTitle(R.string.speak_engine)
        recyclerView.setEdgeEffectColor(primaryColor)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        // 系统默认引擎 header
        adapter.addHeaderView {
            ItemHttpTtsBinding.inflate(layoutInflater, recyclerView, false).apply {
                sysTtsViews.add(cbName)
                ivEdit.gone()
                ivMenuDelete.gone()
                labelSys.visible()
                cbName.text = "系统默认"
                cbName.tag = ""
                cbName.isChecked = ttsEngine == null || run {
                    val selectItem = GSON.fromJsonObject<SelectItem<String>>(ttsEngine).getOrNull()
                    selectItem?.value.isNullOrEmpty()
                }
                cbName.setOnClickListener { upTts(GSON.toJson(SelectItem("系统默认", ""))) }
            }
        }

        // 遍历系统TTS引擎添加header
        viewModel.sysEngines.forEach { engine ->
            adapter.addHeaderView {
                ItemHttpTtsBinding.inflate(layoutInflater, recyclerView, false).apply {
                    sysTtsViews.add(cbName)
                    ivEdit.gone()
                    ivMenuDelete.gone()
                    labelSys.visible()
                    cbName.text = engine.label
                    cbName.tag = engine.name
                    val selectedVal = GSON.fromJsonObject<SelectItem<String>>(ttsEngine).getOrNull()?.value
                    cbName.isChecked = selectedVal == cbName.tag
                    cbName.setOnClickListener { upTts(GSON.toJson(SelectItem(engine.label, engine.name))) }
                }
            }
        }

        // WS分割线header
        adapter.addHeaderView {
            ItemHttpTtsBinding.inflate(layoutInflater, recyclerView, false).apply {
                cbName.text = "———— WebSocket 引擎 ————"
                cbName.isChecked = false
                cbName.isEnabled = false
                ivEdit.gone()
                ivMenuDelete.gone()
                labelSys.gone()
            }
        }

        // 底部按钮
        tvFooterLeft.setText(R.string.book)
        tvFooterLeft.visible()
        tvFooterLeft.setOnClickListener {
            ReadBook.book?.setTtsEngine(ttsEngine)
            callBack?.upSpeakEngineSummary()
            ReadAloud.upReadAloudClass()
            dismissAllowingStateLoss()
        }

        tvOk.setText(R.string.general)
        tvOk.visible()
        tvOk.setOnClickListener {
            ReadBook.book?.setTtsEngine(null)
            AppConfig.ttsEngine = ttsEngine
            callBack?.upSpeakEngineSummary()
            ReadAloud.upReadAloudClass()
            dismissAllowingStateLoss()
        }

        tvCancel.visible()
        tvCancel.setOnClickListener { dismissAllowingStateLoss() }
    }

    private fun initMenu() = binding.run {
        toolBar.inflateMenu(R.menu.speak_engine)
        toolBar.menu.applyTint(requireContext())
        toolBar.setOnMenuItemClickListener(this@SpeakEngineDialog)
    }

    private fun initData() {
        lifecycleScope.launch {
            appDb.httpTTSDao.flowAll()
                .catch { AppLog.put("朗读引擎界面获取数据失败\n${it.localizedMessage}", it) }
                .flowOn(IO)
                .conflate()
                .collect { loadWsEngines() }
        }
        loadWsEngines()
    }

    private fun loadWsEngines() {
        rebuildAdapterWithWsEngines(getSavedWsEngines())
    }

    private fun getSavedWsEngines(): List<AdvancedTtsConfig> {
        val prefs = requireContext().getSharedPreferences("advanced_tts_prefs", Context.MODE_PRIVATE)
        val json = prefs.getString("configs_list", null)
        return if (json.isNullOrEmpty()) emptyList() else try {
            val type = object : com.google.gson.reflect.TypeToken<List<AdvancedTtsConfig>>() {}.type
            GSON.fromJson(json, type) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun rebuildAdapterWithWsEngines(wsConfigs: List<AdvancedTtsConfig>) {
        val httpItems = (adapter.getItems() as? MutableList<HttpTTS>) ?: mutableListOf()
        val wsItems = wsConfigs.map { config ->
            HttpTTS(
                id = (WS_ENGINE_PREFIX + config.id).hashCode().toLong(),
                name = "🔊 ${config.name}",
                url = config.wsUrl,
                concurrentRate = config.concurrentRate.toString(),
                loginUrl = config.preSteps.firstOrNull()?.url,
                loginCheckJs = config.preSteps.firstOrNull()?.parseJs,
                header = config.preSteps.firstOrNull()?.headers,
                jsLib = config.jsLib,
                pauseDuration = config.interval
            )
        }
        adapter.setItems(httpItems + wsItems)
        adapter.notifyDataSetChanged()
    }

    override fun onMenuItemClick(item: MenuItem?): Boolean {
        return when (item?.itemId) {
            R.id.menu_clear -> {
                clearCache()
                true
            }
            R.id.menu_add -> {
                showDialogFragment<HttpTtsEditDialog>()
                true
            }
            R.id.menu_add_ws -> {
                startActivity<AdvancedWsEngineActivity>()
                dismissAllowingStateLoss()
                true
            }
            R.id.menu_default -> {
                viewModel.importDefault()
                true
            }
            R.id.menu_import_local -> {
                importDocResult.launch {
                    mode = HandleFileContract.FILE
                    allowExtensions = arrayOf("txt", "json")
                }
                true
            }
            R.id.menu_import_onLine -> {
                importAlert()
                true
            }
            R.id.menu_export_all -> {
                exportDirResult.launch {
                    mode = HandleFileContract.EXPORT
                    fileData = HandleFileContract.FileData(
                        "httpTts.json",
                        GSON.toJson(adapter.getItems()).toByteArray(),
                        "application/json"
                    )
                }
                true
            }
            R.id.menu_export -> {
                if (currentSelect == -1) {
                    toastOnUi(R.string.is_system_tts_no_export)
                    return true
                }
                val tts = adapter.getItem(currentSelect) ?: return true
                exportDirResult.launch {
                    mode = HandleFileContract.EXPORT
                    fileData = HandleFileContract.FileData(
                        "httpTts_${tts.name}.json",
                        GSON.toJson(tts).toByteArray(),
                        "application/json"
                    )
                }
                true
            }
            else -> false
        }
    }

    fun clearCache() = execute {
        ReadAloud.upReadAloudClass()
        FileUtils.listDirsAndFiles("${requireContext().cacheDir.absolutePath}${File.separator}httpTTS${File.separator}")
            ?.forEach { FileUtils.delete(it.absolutePath) }
        toastOnUi(R.string.clear_cache_success)
    }

    private fun importAlert() {
        val aCache = ACache.get(cacheDir = false)
        val cacheUrls: MutableList<String> = aCache.getAsString(ttsUrlKey)
            ?.splitNotBlank(",")
            ?.toMutableList() ?: mutableListOf()

        alert(R.string.import_on_line) {
            val alertBinding = DialogEditTextBinding.inflate(layoutInflater).apply {
                editView.hint = "url"
                editView.setFilterValues(cacheUrls)
                editView.delCallBack = {
                    cacheUrls.remove(it)
                    aCache.put(ttsUrlKey, cacheUrls.joinToString(","))
                }
            }
            customView { alertBinding.root }
            okButton {
                alertBinding.editView.text?.toString()?.let { url ->
                    if (url.isAbsUrl() && !cacheUrls.contains(url)) {
                        cacheUrls.add(0, url)
                        aCache.put(ttsUrlKey, cacheUrls.joinToString(","))
                    }
                    showDialogFragment(ImportHttpTtsDialog(url))
                }
            }
        }
    }

    private fun upTts(tts: String) {
        ttsEngine = tts
        sysTtsViews.forEach {
            val selectedVal = GSON.fromJsonObject<SelectItem<String>>(ttsEngine).getOrNull()?.value
            val isChecked = selectedVal == it.tag
            if (isChecked) currentSelect = -1
            it.isChecked = isChecked
        }
        adapter.notifyItemRangeChanged(adapter.getHeaderCount(), adapter.itemCount)
    }

    inner class Adapter(context: Context) : RecyclerAdapter<HttpTTS, ItemHttpTtsBinding>(context) {
        override fun getViewBinding(parent: ViewGroup): ItemHttpTtsBinding {
            return ItemHttpTtsBinding.inflate(inflater, parent, false)
        }

        override fun convert(
            holder: ItemViewHolder,
            binding: ItemHttpTtsBinding,
            item: HttpTTS,
            payloads: MutableList<Any>
        ) {
            binding.apply {
                cbName.text = item.name
                val itemIdStr = item.id.toString()
                val isChecked = itemIdStr == ttsEngine
                if (isChecked) currentSelect = holder.layoutPosition - getHeaderCount()
                cbName.isChecked = isChecked

                // 修复：强转TextView，使用原生setText方法，规避text属性找不到报错
                if (itemIdStr.startsWith(WS_ENGINE_PREFIX)) {
                    (labelSys as TextView).setText("WS")
                    labelSys.visibility = View.VISIBLE
                } else {
                    labelSys.visibility = View.GONE
                }
            }
        }

        override fun registerListener(holder: ItemViewHolder, binding: ItemHttpTtsBinding) {
            binding.run {
                cbName.setOnClickListener {
                    getItemByLayoutPosition(holder.layoutPosition)?.let { httpTTS ->
                        val id = httpTTS.id.toString()
                        upTts(id)
                        if (!id.startsWith(WS_ENGINE_PREFIX) && httpTTS.shouldOpenLoginOnSelection()) {
                            startActivity<SourceLoginActivity> {
                                putExtra("type", "httpTts")
                                putExtra("key", id)
                            }
                        }
                    }
                }

                cbName.setOnLongClickListener {
                    getItemByLayoutPosition(holder.layoutPosition)?.let { httpTTS ->
                        if (!httpTTS.id.toString().startsWith(WS_ENGINE_PREFIX) && httpTTS.hasLoginCapability()) {
                            startActivity<SourceLoginActivity> {
                                putExtra("type", "httpTts")
                                putExtra("key", httpTTS.id.toString())
                            }
                            return@setOnLongClickListener true
                        }
                    }
                    false
                }

                ivEdit.setOnClickListener {
                    val item = getItemByLayoutPosition(holder.layoutPosition) ?: return@setOnClickListener
                    if (!item.id.toString().startsWith(WS_ENGINE_PREFIX)) {
                        showDialogFragment(HttpTtsEditDialog(item.id))
                    } else {
                        val wsConfig = getSavedWsEngines().firstOrNull {
                            (WS_ENGINE_PREFIX + it.id).hashCode().toLong() == item.id
                        }
                        wsConfig?.let {
                            startActivity<AdvancedWsEngineActivity> {
                                putExtra("config_id", it.id)
                            }
                            dismissAllowingStateLoss()
                        }
                    }
                }

                ivMenuDelete.setOnClickListener {
                    getItemByLayoutPosition(holder.layoutPosition)?.let { httpTTS ->
                        if (httpTTS.id.toString().startsWith(WS_ENGINE_PREFIX)) {
                            val wsConfig = getSavedWsEngines().firstOrNull {
                                (WS_ENGINE_PREFIX + it.id).hashCode().toLong() == httpTTS.id
                            }
                            wsConfig?.let { config ->
                                alert(R.string.draw) {
                                    setMessage("确认删除 WS 引擎：${config.name}？")
                                    noButton()
                                    yesButton {
                                        val prefs = requireContext().getSharedPreferences("advanced_tts_prefs", Context.MODE_PRIVATE)
                                        val json = prefs.getString("configs_list", null)
                                        if (!json.isNullOrEmpty()) try {
                                            val type = object : com.google.gson.reflect.TypeToken<List<AdvancedTtsConfig>>() {}.type
                                            val list: MutableList<AdvancedTtsConfig> = GSON.fromJson(json, type) ?: mutableListOf()
                                            list.removeAll { cfg -> cfg.id == config.id }
                                            prefs.edit().putString("configs_list", GSON.toJson(list)).apply()
                                            loadWsEngines()
                                            toastOnUi("已删除")
                                        } catch (_: Exception) {
                                            toastOnUi("删除失败")
                                        }
                                    }
                                }
                            }
                        } else {
                            alert(R.string.draw) {
                                setMessage(getString(R.string.sure_del) + "\n" + httpTTS.name)
                                noButton()
                                yesButton {
                                    httpTTS.clearSharedGlobalState()
                                    appDb.httpTTSDao.delete(httpTTS)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    interface CallBack {
        fun upSpeakEngineSummary()
    }
}
