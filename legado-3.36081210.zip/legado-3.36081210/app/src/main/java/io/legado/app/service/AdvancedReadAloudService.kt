package io.legado.app.service

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.net.Uri
import androidx.core.net.toUri
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.CacheDataSink
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.offline.Downloader
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import io.legado.app.R
import io.legado.app.constant.AppLog
import io.legado.app.constant.AppPattern
import io.legado.app.data.entities.AdvancedTtsConfig
import io.legado.app.exception.NoStackTraceException
import io.legado.app.help.config.AppConfig
import io.legado.app.help.coroutine.Coroutine
import io.legado.app.model.ReadAloud
import io.legado.app.model.ReadBook
import io.legado.app.ui.book.read.page.entities.TextChapter
import io.legado.app.utils.FileUtils
import io.legado.app.utils.GSON
import io.legado.app.utils.MD5Utils
import io.legado.app.utils.servicePendingIntent
import io.legado.app.utils.toastOnUi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import splitties.init.appCtx
import java.io.File
import java.io.InputStream
import java.net.ConnectException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

private const val ADV_TTS_MEDIA_ID_PREFIX = "adv-tts:"
private const val ADV_TTS_PAUSE_MEDIA_ID_PREFIX = "adv-tts-pause:"

@SuppressLint("UnsafeOptInUsageError")
class AdvancedReadAloudService : BaseReadAloudService(), Player.Listener {

    private val exoPlayer: ExoPlayer by lazy { ExoPlayer.Builder(this).build() }
    private val ttsFolderPath: String by lazy { cacheDir.absolutePath + File.separator + "advancedTTS" + File.separator }
    private val cache by lazy { SimpleCache(File(cacheDir, "advancedTTS_cache"), LeastRecentlyUsedCacheEvictor(128 * 1024 * 1024), StandaloneDatabaseProvider(appCtx)) }
    private val cacheDataSinkFactory by lazy { CacheDataSink.Factory().setCache(cache) }
    private val loadErrorHandlingPolicy by lazy { CustomLoadErrorHandlingPolicy() }
    private var speechRate: Int = AppConfig.speechRatePlay + 5
    private var downloadTask: Coroutine<*>? = null
    private var playIndexJob: Job? = null
    private var downloadErrorNo: Int = 0
    private var playErrorNo = 0
    private val downloadTaskActiveLock = Mutex()
    private val playbackSessionId = AtomicLong()
    private val activeDownloader = AtomicReference<Downloader?>()
    private var wsClient: WebSocket? = null
    private val wsResponseBuffer = mutableListOf<ByteArray>()
    private var wsConnected = false

    override fun onCreate() {
        super.onCreate()
        exoPlayer.addListener(this)
    }

    override fun onDestroy() {
        invalidatePlaybackSession()
        cancelDownloadTask()
        closeWebSocket()
        super.onDestroy()
        exoPlayer.release()
        cache.release()
        Coroutine.async { removeCacheFile() }
    }

    override fun play() {
        pageChanged = false
        playStop()
        if (!requestFocus()) return
        if (contentList.isEmpty()) {
            AppLog.putDebug("朗读列表为空")
            ReadBook.readAloud()
        } else {
            super.play()
            downloadAndPlayAudiosStream()
        }
    }

    override fun playStop() {
        invalidatePlaybackSession()
        cancelDownloadTask()
        closeWebSocket()
        exoPlayer.stop()
        exoPlayer.clearMediaItems()
        playIndexJob?.cancel()
    }

    private fun updateNextPos() {
        readAloudNumber += contentList[nowSpeak].length + 1 - paragraphStartPos
        paragraphStartPos = 0
        if (nowSpeak < contentList.lastIndex) nowSpeak++
        else nextChapter(auto = true)
    }

    private fun downloadAndPlayAudiosStream() {
        val sessionId = startPlaybackSession()
        exoPlayer.clearMediaItems()
        downloadTask = execute {
            downloadTaskActiveLock.withLock {
                currentCoroutineContext().ensureActive()
                ensureSessionActive(sessionId)
                val config = getAdvancedTtsConfig() ?: throw NoStackTraceException("advanced tts config is null")
                val variables = mutableMapOf<String, String>()
                executePreSteps(config, variables)
                connectWebSocket(config, variables, sessionId)
                contentList.forEachIndexed { index, content ->
                    currentCoroutineContext().ensureActive()
                    ensureSessionActive(sessionId)
                    if (index < nowSpeak) return@forEachIndexed
                    var text = content
                    if (paragraphStartPos > 0 && index == nowSpeak) text = text.substring(paragraphStartPos)
                    val speakText = text.replace(AppPattern.notReadAloudRegex, "")
                    if (speakText.isEmpty()) AppLog.put("阅读段落内容为空，使用无声音频代替。\n朗读文本：$text")
                    val fileName = md5SpeakFileName(text)
                    if (hasSpeakFile(fileName)) {
                        val file = getSpeakFileAsMd5(fileName)
                        val mediaItem = createQueueMediaItem(Uri.fromFile(file), index, sessionId)
                        val pauseDuration = normalizePauseDuration(config.pauseDuration)
                        val pauseItem = if (shouldInsertPause(index, contentList.lastIndex, pauseDuration)) createPauseMediaItem(Uri.fromFile(getOrCreatePauseFile(pauseDuration)), pauseDuration, sessionId) else null
                        enqueueMediaItems(sessionId, listOfNotNull(mediaItem, pauseItem))
                        return@forEachIndexed
                    }
                    val audioData = requestSynthesis(speakText, config, sessionId)
                    if (audioData != null) {
                        val inputStream = audioData.inputStream()
                        createSpeakFile(fileName, inputStream)
                        val file = getSpeakFileAsMd5(fileName)
                        val mediaItem = createQueueMediaItem(Uri.fromFile(file), index, sessionId)
                        val pauseDuration = normalizePauseDuration(config.pauseDuration)
                        val pauseItem = if (shouldInsertPause(index, contentList.lastIndex, pauseDuration)) createPauseMediaItem(Uri.fromFile(getOrCreatePauseFile(pauseDuration)), pauseDuration, sessionId) else null
                        enqueueMediaItems(sessionId, listOfNotNull(mediaItem, pauseItem))
                    } else {
                        createSilentSound(fileName)
                        val file = getSpeakFileAsMd5(fileName)
                        val mediaItem = createQueueMediaItem(Uri.fromFile(file), index, sessionId)
                        val pauseDuration = normalizePauseDuration(config.pauseDuration)
                        val pauseItem = if (shouldInsertPause(index, contentList.lastIndex, pauseDuration)) createPauseMediaItem(Uri.fromFile(getOrCreatePauseFile(pauseDuration)), pauseDuration, sessionId) else null
                        enqueueMediaItems(sessionId, listOfNotNull(mediaItem, pauseItem))
                    }
                }
                ensureSessionActive(sessionId)
                preDownloadAudios(config, sessionId)
            }
        }.onError {
            AppLog.put("朗读下载出错\n${it.localizedMessage}", it, true)
        }
    }

    private suspend fun executePreSteps(config: AdvancedTtsConfig, variables: MutableMap<String, String>) {
        val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
        config.preSteps.forEachIndexed { index, step ->
            currentCoroutineContext().ensureActive()
            try {
                val url = replaceVariables(step.url, variables)
                val requestBuilder = Request.Builder().url(url)
                step.headers.split("\n").forEach { line ->
                    val trimmed = line.trim()
                    if (trimmed.isNotEmpty() && trimmed.contains(":")) {
                        val (key, value) = trimmed.split(":", limit = 2)
                        requestBuilder.addHeader(key.trim(), replaceVariables(value.trim(), variables))
                    }
                }
                if (step.method.uppercase() == "POST") {
                    val bodyStr = replaceVariables(step.body, variables)
                    requestBuilder.post(okhttp3.RequestBody.create(null, bodyStr))
                }
                val response = client.newCall(requestBuilder.build()).execute()
                val responseBody = response.body?.string() ?: ""
                if (step.parseJs.isNotBlank()) executeJs(step.parseJs, responseBody, variables)
                response.close()
            } catch (e: Exception) {
                AppLog.put("前置请求第${index+1}步失败: ${e.localizedMessage}", e)
                throw e
            }
        }
    }

    private suspend fun connectWebSocket(config: AdvancedTtsConfig, variables: MutableMap<String, String>, sessionId: Long) {
        val url = replaceVariables(config.wsUrlTemplate, variables)
        val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(300, TimeUnit.SECONDS).build()
        wsResponseBuffer.clear()
        val latch = java.util.concurrent.CountDownLatch(1)
        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                wsConnected = true
                wsClient = webSocket
                try {
                    val sendMsg = replaceVariables(config.sendScript, variables).replace("speakText", "initial")
                    webSocket.send(sendMsg)
                    latch.countDown()
                } catch (e: Exception) { latch.countDown() }
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { wsResponseBuffer.add(bytes.toByteArray()) }
            override fun onMessage(webSocket: WebSocket, text: String) {
                if (config.parseMode == 5) {
                    try {
                        val result = executeJs(config.customParseScript ?: "", text, variables)
                        if (result is ByteArray) wsResponseBuffer.add(result)
                    } catch (_: Exception) {}
                }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { wsConnected = false }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                wsConnected = false
                AppLog.put("WebSocket失败: ${t.localizedMessage}", t)
            }
        }
        client.newWebSocket(Request.Builder().url(url).build(), listener)
        if (!latch.await(30, TimeUnit.SECONDS)) throw ConnectException("WebSocket连接超时")
    }

    private suspend fun requestSynthesis(text: String, config: AdvancedTtsConfig, sessionId: Long): ByteArray? {
        val ws = wsClient ?: return null
        if (!wsConnected) return null
        try {
            ws.send(replaceVariables(config.sendScript, mutableMapOf("speakText" to text)))
        } catch (e: Exception) {
            AppLog.put("发送合成请求失败: ${e.localizedMessage}", e)
            return null
        }
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < 30000) {
            currentCoroutineContext().ensureActive()
            if (wsResponseBuffer.isNotEmpty()) return wsResponseBuffer.removeAt(0)
            delay(50)
        }
        return null
    }

    private fun closeWebSocket() {
        wsClient?.close(1000, "session end")
        wsClient = null
        wsConnected = false
    }

    private fun replaceVariables(template: String, variables: Map<String, String>): String {
        var result = template
        variables.forEach { (key, value) ->
            result = result.replace("{{$key}}", value)
        }
        return result
    }

    @Suppress("UNUSED_PARAMETER")
    private fun executeJs(script: String, responseBody: String, variables: MutableMap<String, String>): Any? = null

    // 🔴 这里才是真正改好的 getAdvancedTtsConfig
    private fun getAdvancedTtsConfig(): AdvancedTtsConfig? {
        val ttsEngine = ReadAloud.ttsEngine
        if (ttsEngine.isNullOrBlank() || !ttsEngine.startsWith("ws_")) return null
        val idStr = ttsEngine.removePrefix("ws_")
        val prefs = appCtx.getSharedPreferences("advanced_tts_prefs", Context.MODE_PRIVATE)
        val json = prefs.getString("configs_list", null) ?: return null
        return try {
            val type = object : com.google.gson.reflect.TypeToken<List<AdvancedTtsConfig>>() {}.type
            val list: List<AdvancedTtsConfig> = GSON.fromJson(json, type) ?: emptyList()
            // 🔴 修正：都转成 String 比较，解决类型不匹配
            list.firstOrNull { it.id.toString() == idStr }
        } catch (e: Exception) {
            AppLog.put("解析 WS 引擎配置失败: ${e.localizedMessage}", e)
            null
        }
    }

    private fun normalizePauseDuration(durationMs: Int): Int = durationMs.coerceIn(0, 10_000)
    private fun shouldInsertPause(index: Int, lastIndex: Int, durationMs: Int): Boolean = index < lastIndex && normalizePauseDuration(durationMs) > 0

    private fun md5SpeakFileName(content: String, textChapter: TextChapter? = this.textChapter): String {
        val config = getAdvancedTtsConfig()
        val cacheIdentity = buildString {
            arrayOf(config?.wsUrl.orEmpty(), speechRate.toString(), content).forEach { append(it.length).append(':').append(it) }
        }
        val audioKey = MD5Utils.md5Encode16(cacheIdentity)
        val chapterKey = MD5Utils.md5Encode16(textChapter?.title.orEmpty())
        return "${chapterKey}_$audioKey"
    }

    private fun createSilentSound(fileName: String) = createSpeakFile(fileName).writeBytes(resources.openRawResource(R.raw.silent_sound).readBytes())
    private fun hasSpeakFile(name: String): Boolean = FileUtils.exist("${ttsFolderPath}$name.mp3")
    private fun getSpeakFileAsMd5(name: String): File = File("${ttsFolderPath}$name.mp3")
    private fun createSpeakFile(name: String): File = FileUtils.createFileIfNotExist("${ttsFolderPath}$name.mp3")
    private suspend fun createSpeakFile(name: String, inputStream: InputStream) {
        val file = FileUtils.createFileIfNotExist("${ttsFolderPath}$name.mp3")
        try { runInterruptible { file.outputStream().use { out -> inputStream.use { it.copyTo(out) } } } }
        catch (throwable: Throwable) { file.delete(); throw throwable }
    }

    private fun getOrCreatePauseFile(durationMs: Int): File {
        val file = FileUtils.createFileIfNotExist("${ttsFolderPath}pause_$durationMs.wav")
        if (file.length() == 0L) file.writeBytes(generateSilentWavBytes(durationMs))
        return file
    }

    private fun generateSilentWavBytes(durationMs: Int): ByteArray {
        val normalizedDuration = durationMs.coerceIn(0, 10_000)
        val sampleRate = 24_000; val channelCount = 1; val bitsPerSample = 16; val bytesPerSample = bitsPerSample / 8
        val dataSize = sampleRate * channelCount * bytesPerSample * normalizedDuration / 1000
        return ByteBuffer.allocate(44 + dataSize).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII)); putInt(36 + dataSize)
            put("WAVE".toByteArray(Charsets.US_ASCII)); put("fmt ".toByteArray(Charsets.US_ASCII)); putInt(16)
            putShort(1.toShort()); putShort(channelCount.toShort()); putInt(sampleRate); putInt(sampleRate * channelCount * bytesPerSample)
            putShort((channelCount * bytesPerSample).toShort()); putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII)); putInt(dataSize)
        }.array()
    }

    private fun createQueueMediaItem(uri: Uri, index: Int, sessionId: Long): MediaItem =
        MediaItem.Builder().setUri(uri).setMediaId("$ADV_TTS_MEDIA_ID_PREFIX$sessionId:$index").build()
    private fun createPauseMediaItem(uri: Uri, durationMs: Int, sessionId: Long): MediaItem =
        MediaItem.Builder().setUri(uri).setMediaId("$ADV_TTS_PAUSE_MEDIA_ID_PREFIX$sessionId:$durationMs").build()

    private suspend fun preDownloadAudios(config: AdvancedTtsConfig, sessionId: Long) {
        val textChapter = ReadBook.nextTextChapter ?: return
        val contentList = textChapter.getNeedReadAloud(0, readAloudByPage, 0, 1).splitToSequence("\n").filter { it.isNotEmpty() }.take(10).toList()
        contentList.forEach { content ->
            currentCoroutineContext().ensureActive()
            val fileName = md5SpeakFileName(content, textChapter)
            val speakText = content.replace(AppPattern.notReadAloudRegex, "")
            if (speakText.isEmpty()) createSilentSound(fileName)
            else if (!hasSpeakFile(fileName)) runCatching {
                val audioData = requestSynthesis(speakText, config, sessionId)
                if (audioData != null) createSpeakFile(fileName, audioData.inputStream())
                else createSilentSound(fileName)
            }
        }
    }

    private suspend fun enqueueMediaItems(sessionId: Long, mediaItems: List<MediaItem>) {
        awaitQueueSlots(sessionId, mediaItems.size)
        withContext(Main) {
            if (!isSessionActive(sessionId)) return@withContext
            mediaItems.forEach(exoPlayer::addMediaItem)
        }
        ensureSessionActive(sessionId)
    }

    private suspend fun awaitQueueSlots(sessionId: Long, requiredSlots: Int) {
        while (true) {
            currentCoroutineContext().ensureActive()
            ensureSessionActive(sessionId)
            if (pause) { delay(1_000L); continue }
            val hasCapacity = withContext(Main) {
                if (!isSessionActive(sessionId)) return@withContext false
                trimPlayedMediaItems()
                requiredSlots in 1..12 && exoPlayer.mediaItemCount in 0..(12 - requiredSlots)
            }
            if (hasCapacity) return
            delay(80L)
        }
    }

    private fun trimPlayedMediaItems() {
        val currentIndex = exoPlayer.currentMediaItemIndex
        if (currentIndex > 0) exoPlayer.removeMediaItems(0, currentIndex)
    }

    private fun removeCacheFile() {
        val titleMd5 = MD5Utils.md5Encode16(textChapter?.title ?: "")
        FileUtils.listDirsAndFiles(ttsFolderPath)?.forEach {
            val isSilentSound = it.length() == 2160L
            if ((!it.name.startsWith(titleMd5) && System.currentTimeMillis() - it.lastModified() > 600000) || isSilentSound) FileUtils.delete(it.absolutePath)
        }
    }

    override fun pauseReadAloud(abandonFocus: Boolean) {
        super.pauseReadAloud(abandonFocus)
        kotlin.runCatching { playIndexJob?.cancel(); exoPlayer.pause() }
    }

    override fun resumeReadAloud() {
        super.resumeReadAloud()
        kotlin.runCatching {
            if (pageChanged) play()
            else { exoPlayer.play(); upPlayPos() }
        }
    }

    private fun upPlayPos() {
        playIndexJob?.cancel()
        val textChapter = textChapter ?: return
        playIndexJob = lifecycleScope.launch {
            upTtsProgress(readAloudNumber + 1)
            if (exoPlayer.duration <= 0) return@launch
            val speakTextLength = contentList[nowSpeak].length
            if (speakTextLength <= 0) return@launch
            val sleep = exoPlayer.duration / speakTextLength
            val start = speakTextLength * exoPlayer.currentPosition / exoPlayer.duration
            for (i in start..contentList[nowSpeak].length) {
                if (pageIndex + 1 < textChapter.pageSize && readAloudNumber + i > textChapter.getReadLength(pageIndex + 1)) {
                    pageIndex++
                    ReadBook.moveToNextPage(syncReadAloudFollow = true)
                    upTtsProgress(readAloudNumber + i.toInt())
                }
                delay(sleep)
            }
        }
    }

    override fun upSpeechRate(reset: Boolean) { playStop(); speechRate = AppConfig.speechRatePlay + 5; downloadAndPlayAudiosStream() }

    override fun onPlaybackStateChanged(playbackState: Int) {
        when (playbackState) {
            Player.STATE_READY -> {
                if (pause) return
                if (!isCurrentSessionMediaItem(exoPlayer.currentMediaItem)) return
                exoPlayer.play()
                if (!isPauseMediaItem(exoPlayer.currentMediaItem)) upPlayPos()
            }
            Player.STATE_ENDED -> {
                if (!isCurrentSessionMediaItem(exoPlayer.currentMediaItem)) return
                playErrorNo = 0; updateNextPos(); exoPlayer.stop(); exoPlayer.clearMediaItems()
            }
        }
    }

    override fun onTimelineChanged(timeline: Timeline, reason: Int) {
        if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED && !timeline.isEmpty && exoPlayer.playbackState == Player.STATE_IDLE) {
            exoPlayer.prepare()
        }
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) return
        if (!isCurrentSessionMediaItem(mediaItem)) return
        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) playErrorNo = 0
        trimPlayedMediaItems()
        if (isPauseMediaItem(mediaItem)) return
        updateNextPos(); upPlayPos()
    }

    override fun onPlayerError(error: PlaybackException) {
        val mediaItem = exoPlayer.currentMediaItem ?: return
        if (!isCurrentSessionMediaItem(mediaItem)) return
        if (isPauseMediaItem(mediaItem)) {
            trimPlayedMediaItems()
            if (exoPlayer.hasNextMediaItem()) { exoPlayer.seekToNextMediaItem(); exoPlayer.prepare() }
            return
        }
        contentList.getOrNull(nowSpeak)?.let { AppLog.put("朗读错误\n$it", error) } ?: AppLog.put("朗读错误", error)
        deleteCurrentSpeakFile()
        trimPlayedMediaItems()
        playErrorNo++
        if (playErrorNo >= 5) {
            toastOnUi("朗读连续5次错误, 最后一次错误代码(${error.localizedMessage})")
            AppLog.put("朗读连续5次错误, 最后一次错误代码(${error.localizedMessage})", error)
            pauseReadAloud()
        } else {
            if (exoPlayer.hasNextMediaItem()) { exoPlayer.seekToNextMediaItem(); exoPlayer.prepare() }
            else { exoPlayer.clearMediaItems(); updateNextPos() }
        }
    }

    private fun deleteCurrentSpeakFile() {
        val mediaItem = exoPlayer.currentMediaItem ?: return
        val filePath = mediaItem.localConfiguration?.uri?.path ?: return
        File(filePath).delete()
    }

    override fun aloudServicePendingIntent(actionStr: String): PendingIntent? = servicePendingIntent<AdvancedReadAloudService>(actionStr)

    private fun startPlaybackSession(): Long = playbackSessionId.incrementAndGet()
    private fun cancelDownloadTask() { activeDownloader.getAndSet(null)?.cancel(); downloadTask?.cancel(); downloadTask = null }
    private fun invalidatePlaybackSession() { playbackSessionId.incrementAndGet() }
    private fun isSessionActive(sessionId: Long): Boolean = playbackSessionId.get() == sessionId
    private fun ensureSessionActive(sessionId: Long) { if (!isSessionActive(sessionId)) throw CancellationException("playback session changed") }
    private fun isCurrentSessionMediaItem(mediaItem: MediaItem?): Boolean = mediaItem?.mediaId?.startsWith(ADV_TTS_MEDIA_ID_PREFIX) == true || mediaItem?.mediaId?.startsWith(ADV_TTS_PAUSE_MEDIA_ID_PREFIX) == true
    private fun isPauseMediaItem(mediaItem: MediaItem?): Boolean = mediaItem?.mediaId?.startsWith(ADV_TTS_PAUSE_MEDIA_ID_PREFIX) == true

    class CustomLoadErrorHandlingPolicy : DefaultLoadErrorHandlingPolicy(0) {
        override fun getRetryDelayMsFor(loadErrorInfo: LoadErrorHandlingPolicy.LoadErrorInfo): Long = C.TIME_UNSET
    }
}