package io.legado.app.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.jayway.jsonpath.DocumentContext
import io.legado.app.utils.GSON
import io.legado.app.utils.jsonPath
import io.legado.app.utils.readLong
import io.legado.app.utils.readString

/**
 * 在线朗读引擎
 */
@Entity(tableName = "httpTTS")
data class HttpTTS(
    @PrimaryKey
    val id: Long = System.currentTimeMillis(),
    var name: String = "",
    var url: String = "",
    var contentType: String? = null,
    /**
     * 连接类型：
     *   http - HTTP 模式（默认，兼容原有逻辑）
     *   ws   - WebSocket 模式
     */
    @ColumnInfo(defaultValue = "http")
    var connectionType: String? = "http",
    /**
     * 响应格式：
     *   direct   - 直接返回音频二进制流（默认，兼容原有逻辑）
     *   jsonBase64 - 返回 JSON，从指定字段提取 base64 音频
     */
    @ColumnInfo(defaultValue = "direct")
    var responseFormat: String? = "direct",
    /**
     * JSON 响应中存放 base64 音频数据的字段名
     * 当 responseFormat = jsonBase64 时生效
     * 支持 data:xxx;base64, 前缀，会自动剥离
     */
    @ColumnInfo(defaultValue = "audio")
    var audioField: String? = "audio",
    @ColumnInfo(defaultValue = "0")
    override var concurrentRate: String? = "0",
    override var loginUrl: String? = null,
    override var loginUi: String? = null,
    override var header: String? = null,
    override var jsLib: String? = null,
    @ColumnInfo(defaultValue = "0")
    override var enabledCookieJar: Boolean? = false,
    var loginCheckJs: String? = null,
    /**
     * ====== WebSocket 模式专用字段（connectionType = "ws" 时生效）======
     * wsOnOpenJs:    WS 连接建立后执行的 JS，通常用于发送 StartTask 握手帧
     *                注入变量：ws (WsProxy)、java (JsExtensions)、speakText、speakSpeed
     * wsOnMessageJs: 收到 WS 文本/二进制消息时执行的 JS
     *                注入变量：ws、java、message(String) / bytes(ByteArray)、isText(Boolean)
     * wsOnCloseJs:   WS 连接关闭后执行的 JS（可选）
     *                注入变量：ws、java、code(Int)、reason(String)
     * wsResultJs:    WS 流程结束后执行的 JS，必须返回音频 byte[]（或 null 表示失败）
     *                注入变量：java
     *
     * 设计思路：WS 的收帧、拼接、情绪处理等协议差异全部在 JS 层解决，
     *           原生层只负责建连、转发事件、收集最终音频。
     *           这样猫箱/千问/文心等不同 WS 协议各写各的 JSON，不改源码。
     */
    var wsOnOpenJs: String? = null,
    var wsOnMessageJs: String? = null,
    var wsOnCloseJs: String? = null,
    var wsResultJs: String? = null,
    @ColumnInfo(defaultValue = "0")
    var lastUpdateTime: Long = System.currentTimeMillis()
) : BaseSource {

    override fun getTag(): String {
        return name
    }

    override fun getKey(): String {
        return "httpTts:$id"
    }

    fun equal(source: HttpTTS): Boolean {
        return name == source.name &&
                url == source.url &&
                contentType == source.contentType &&
                connectionType == source.connectionType &&
                responseFormat == source.responseFormat &&
                audioField == source.audioField &&
                concurrentRate == source.concurrentRate &&
                loginUrl == source.loginUrl &&
                loginUi == source.loginUi &&
                header == source.header &&
                jsLib == source.jsLib &&
                enabledCookieJar == source.enabledCookieJar &&
                loginCheckJs == source.loginCheckJs &&
                wsOnOpenJs == source.wsOnOpenJs &&
                wsOnMessageJs == source.wsOnMessageJs &&
                wsOnCloseJs == source.wsOnCloseJs &&
                wsResultJs == source.wsResultJs
    }

    @Suppress("MemberVisibilityCanBePrivate")
    companion object {

        fun fromJsonDoc(doc: DocumentContext): Result<HttpTTS> {
            return kotlin.runCatching {
                val loginUi = doc.read<Any>("$.loginUi")
                HttpTTS(
                    id = doc.readLong("$.id") ?: System.currentTimeMillis(),
                    name = doc.readString("$.name")!!,
                    url = doc.readString("$.url")!!,
                    contentType = doc.readString("$.contentType"),
                    connectionType = doc.readString("$.connectionType") ?: "http",
                    responseFormat = doc.readString("$.responseFormat") ?: "direct",
                    audioField = doc.readString("$.audioField") ?: "audio",
                    concurrentRate = doc.readString("$.concurrentRate"),
                    loginUrl = doc.readString("$.loginUrl"),
                    loginUi = if (loginUi is List<*>) GSON.toJson(loginUi) else loginUi?.toString(),
                    header = doc.readString("$.header"),
                    loginCheckJs = doc.readString("$.loginCheckJs"),
                    wsOnOpenJs = doc.readString("$.wsOnOpenJs"),
                    wsOnMessageJs = doc.readString("$.wsOnMessageJs"),
                    wsOnCloseJs = doc.readString("$.wsOnCloseJs"),
                    wsResultJs = doc.readString("$.wsResultJs"),
                    lastUpdateTime = doc.readLong("$.lastUpdateTime") ?: System.currentTimeMillis(),
                    jsLib = doc.readString("$.jsLib")
                )
            }
        }

        fun fromJson(json: String): Result<HttpTTS> {
            return fromJsonDoc(jsonPath.parse(json))
        }

        fun fromJsonArray(jsonArray: String): Result<ArrayList<HttpTTS>> {
            return kotlin.runCatching {
                val sources = arrayListOf<HttpTTS>()
                val doc = jsonPath.parse(jsonArray).read<List<*>>("$")
                doc.forEach {
                    val jsonItem = jsonPath.parse(it)
                    fromJsonDoc(jsonItem).getOrThrow().let { source ->
                        sources.add(source)
                    }
                }
                return@runCatching sources
            }
        }

    }

}
