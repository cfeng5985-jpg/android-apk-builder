package io.legado.app.service.wstts

import io.legado.app.data.entities.HttpTTS
import io.legado.app.exception.NoStackTraceException
import io.legado.app.help.http.okHttpClient
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * 百度智能云 WebSocket TTS 引擎（简易版）
 *
 * 【协议说明】
 * 1. 连接地址：wss://aip.baidubce.com/ws/2.0/speech/publiccloudspeech/v1/tts
 *    鉴权方式：URL query 参数携带 access_token
 * 2. 连接建立后，客户端发送 JSON 格式的合成请求
 * 3. 服务端返回：
 *    - 二进制帧：音频数据分片（MP3 或 PCM）
 *    - 文本帧：状态信息，包含 err_no、err_msg、finished 等
 * 4. 收到 finished=true 的文本帧表示合成结束
 *
 * 【简易版特点】
 * - 每段文本新建一个 WebSocket 连接
 * - 收完全部音频分片后拼接返回
 * - 不做连接复用，不做流式播放
 * - 好处：实现简单，完美对接现有 getSpeakStream() 模型
 *
 * 【params 字段说明】
 * {
 *   "per": 3,          // 音色，默认 3（度逍遥）
 *   "spd": 5,          // 语速 0-15，默认 5（会被 speakSpeed 覆盖）
 *   "pit": 5,          // 语调 0-15，默认 5
 *   "vol": 5,          // 音量 0-15，默认 5
 *   "aue": 3,          // 音频格式：3-MP3（默认），6-PCM 16K
 *   "lan": "zh"        // 语言，默认 zh
 * }
 */
class BaiduWsTtsEngine : WsTtsEngine {

    private var webSocket: WebSocket? = null
    private var cancelled = false

    override suspend fun synthesize(
        tts: HttpTTS,
        text: String,
        speed: Int
    ): InputStream {
        cancelled = false

        // 解析 params JSON
        val paramsJson = tts.params?.takeIf { it.isNotBlank() }?.let {
            try {
                JSONObject(it)
            } catch (e: Exception) {
                throw NoStackTraceException("引擎参数 params 不是有效 JSON：${e.message}")
            }
        } ?: JSONObject()

        // 读取参数，有默认值
        val per = paramsJson.optInt("per", 3)
        val spd = speed  // 语速以朗读设置为准，覆盖 params 里的配置
        val pit = paramsJson.optInt("pit", 5)
        val vol = paramsJson.optInt("vol", 5)
        val aue = paramsJson.optInt("aue", 3)  // 3=MP3, 6=PCM 16K
        val lan = paramsJson.optString("lan", "zh")

        // 构建 WebSocket URL
        // url 字段里应该已经包含了 access_token（用户自己拼或者通过 login 机制获取）
        val wsUrl = tts.url.ifBlank {
            throw NoStackTraceException("WebSocket 地址不能为空")
        }

        // 构建请求 JSON
        val requestJson = JSONObject().apply {
            put("tex", text)
            put("per", per)
            put("spd", spd)
            put("pit", pit)
            put("vol", vol)
            put("aue", aue)
            put("lan", lan)
            // ctp 字段：客户端类型，默认 1（web端）
            put("ctp", 1)
            // cuid：客户端唯一标识，用包名即可
            put("cuid", "legado_tts")
        }

        return suspendCancellableCoroutine { continuation ->
            val audioBuffer = ByteArrayOutputStream()
            var errorMessage: String? = null
            var finished = false

            val request = Request.Builder()
                .url(wsUrl)
                .build()

            val listener = object : WebSocketListener() {

                override fun onOpen(ws: WebSocket, response: Response) {
                    // 连接建立，发送合成请求
                    ws.send(requestJson.toString())
                }

                override fun onMessage(ws: WebSocket, text: String) {
                    // 文本帧：状态信息
                    try {
                        val json = JSONObject(text)
                        val errNo = json.optInt("err_no", -1)
                        val errMsg = json.optString("err_msg", "")
                        val isFinished = json.optBoolean("finished", false)

                        if (errNo != 0 && errNo != 3000) {
                            // 3000 是"正在合成"的状态码，不算错误
                            errorMessage = "百度TTS错误 [$errNo]: $errMsg"
                            ws.close(1000, "业务错误")
                            return
                        }

                        if (isFinished) {
                            finished = true
                            ws.close(1000, "合成完成")
                        }
                    } catch (e: Exception) {
                        errorMessage = "解析百度TTS响应失败：${e.message}"
                        ws.close(1000, "解析错误")
                    }
                }

                override fun onMessage(ws: WebSocket, bytes: ByteString) {
                    // 二进制帧：音频数据
                    if (!cancelled) {
                        audioBuffer.write(bytes.toByteArray())
                    }
                }

                override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                    // 服务端关闭连接
                }

                override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                    // 连接已关闭
                    webSocket = null
                    when {
                        cancelled -> {
                            // 用户主动取消，不返回结果
                            continuation.cancel()
                        }
                        errorMessage != null -> {
                            // 有错误
                            continuation.resumeWithException(
                                NoStackTraceException(errorMessage!!)
                            )
                        }
                        audioBuffer.size() > 0 -> {
                            // 成功，返回音频流
                            continuation.resume(
                                ByteArrayInputStream(audioBuffer.toByteArray())
                            )
                        }
                        else -> {
                            // 没收到音频数据
                            continuation.resumeWithException(
                                NoStackTraceException("百度TTS未返回音频数据")
                            )
                        }
                    }
                }

                override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                    // 连接失败
                    webSocket = null
                    if (!continuation.isCompleted) {
                        continuation.resumeWithException(
                            NoStackTraceException("百度TTS连接失败：${t.message}")
                        )
                    }
                }
            }

            webSocket = okHttpClient.newWebSocket(request, listener)

            // 协程取消时关闭 WebSocket
            continuation.invokeOnCancellation {
                cancelled = true
                webSocket?.close(1000, "用户取消")
                webSocket = null
            }
        }
    }

    override fun cancel() {
        cancelled = true
        webSocket?.close(1000, "取消合成")
        webSocket = null
    }
}
