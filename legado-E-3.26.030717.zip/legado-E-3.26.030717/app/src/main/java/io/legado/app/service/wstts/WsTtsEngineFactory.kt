package io.legado.app.service.wstts

import io.legado.app.data.entities.HttpTTS
import io.legado.app.exception.NoStackTraceException

/**
 * WebSocket TTS 引擎工厂
 * 根据 engineType 创建对应的引擎实现
 *
 * 新增厂商时，在这里加一个 when 分支即可，上层代码不用动
 */
object WsTtsEngineFactory {

    /**
     * 创建 WebSocket TTS 引擎实例
     *
     * @param engineType 引擎类型，如 "ws_baidu"、"ws_volc" 等
     * @return 对应的引擎实现
     * @throws NoStackTraceException 不支持的引擎类型
     */
    fun create(engineType: String): WsTtsEngine {
        return when (engineType) {
            "ws_baidu" -> BaiduWsTtsEngine()
            // 后续厂商陆续接入：
            // "ws_volc" -> VolcWsTtsEngine()
            // "ws_ali" -> AliWsTtsEngine()
            // "ws_xf" -> XfWsTtsEngine()
            // "ws_tx" -> TxWsTtsEngine()
            else -> throw NoStackTraceException("不支持的 WebSocket TTS 引擎类型：$engineType")
        }
    }

    /**
     * 判断是否为 WebSocket 类型的引擎
     */
    fun isWsEngine(engineType: String?): Boolean {
        return engineType?.startsWith("ws_") == true
    }

    /**
     * 获取所有支持的引擎类型列表（用于 UI 下拉选择）
     */
    fun getSupportedEngines(): List<Pair<String, String>> {
        return listOf(
            "http" to "HTTP（通用）",
            "ws_baidu" to "百度智能云 WebSocket"
        )
    }
}
