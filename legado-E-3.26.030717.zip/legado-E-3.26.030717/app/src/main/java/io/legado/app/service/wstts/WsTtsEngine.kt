package io.legado.app.service.wstts

import io.legado.app.data.entities.HttpTTS
import java.io.InputStream

/**
 * WebSocket TTS 引擎策略接口
 *
 * 所有 WebSocket TTS 厂商都实现这个接口，
 * HttpReadAloudService 根据 engineType 选择对应的实现。
 *
 * 【简易版设计】
 * 每次调用 synthesize() 都：
 *   1. 新建 WebSocket 连接
 *   2. 发送文本
 *   3. 接收全部音频分片并拼接
 *   4. 关闭连接
 *   5. 返回完整音频 InputStream
 *
 * 这样可以完美对接现有 HttpReadAloudService 的 getSpeakStream() 模型，
 * 不需要改动播放层、缓存层、分段调度等逻辑。
 *
 * 【未来演进方向】
 * 以后做连接复用 / 流式播放时，在这个接口上扩展即可，
 * 上层 Service 不需要大改。
 */
interface WsTtsEngine {

    /**
     * 合成一段文本为音频
     *
     * @param tts HttpTTS 配置（含 url、params、header 等）
     * @param text 待合成的文本
     * @param speed 语速（0-15，和现有 speakSpeed 一致）
     * @return 完整音频的 InputStream
     * @throws Exception 合成失败时抛出，错误信息应可读
     */
    suspend fun synthesize(
        tts: HttpTTS,
        text: String,
        speed: Int
    ): InputStream

    /**
     * 取消当前合成（用户暂停/停止朗读时调用）
     * 简易版下直接关闭 WebSocket 连接即可
     */
    fun cancel()
}
