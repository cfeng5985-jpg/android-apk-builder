package io.legado.app.model.localBook

import android.net.Uri
import android.util.Base64
import androidx.documentfile.provider.DocumentFile
import com.script.ScriptBindings
import com.script.rhino.RhinoScriptEngine
import io.legado.app.R
import io.legado.app.constant.AppLog
import io.legado.app.constant.AppPattern
import io.legado.app.constant.BookType
import io.legado.app.data.appDb
import io.legado.app.data.entities.BaseSource
import io.legado.app.data.entities.Book
import io.legado.app.data.entities.BookChapter
import io.legado.app.exception.EmptyFileException
import io.legado.app.exception.NoBooksDirException
import io.legado.app.exception.NoStackTraceException
import io.legado.app.exception.TocEmptyException
import io.legado.app.help.AppWebDav
import io.legado.app.help.book.BookHelp
import io.legado.app.help.book.ContentProcessor
import io.legado.app.help.book.addType
import io.legado.app.help.book.archiveName
import io.legado.app.help.book.cacheLocalUri
import io.legado.app.help.book.getArchiveUri
import io.legado.app.help.book.getLocalUri
import io.legado.app.help.book.getRemoteUrl
import io.legado.app.help.book.isArchive
import io.legado.app.help.book.isEpub
import io.legado.app.help.book.isMobi
import io.legado.app.help.book.isPdf
import io.legado.app.help.book.isUmd
import io.legado.app.help.book.removeLocalUriCache
import io.legado.app.help.book.simulatedTotalChapterNum
import io.legado.app.help.config.AppConfig
import io.legado.app.lib.webdav.WebDav
import io.legado.app.lib.webdav.WebDavException
import io.legado.app.model.analyzeRule.AnalyzeUrl
import io.legado.app.model.remote.RemoteBook
import io.legado.app.utils.ArchiveUtils
import io.legado.app.utils.FileDoc
import io.legado.app.utils.FileUtils
import io.legado.app.utils.GSON
import io.legado.app.utils.MD5Utils
import io.legado.app.utils.delete
import io.legado.app.utils.externalFiles
import io.legado.app.utils.exists
import io.legado.app.utils.fromJsonObject
import io.legado.app.utils.inputStream
import io.legado.app.utils.isAbsUrl
import io.legado.app.utils.isContentScheme
import io.legado.app.utils.isDataUrl
import io.legado.app.utils.printOnDebug
import kotlinx.coroutines.runBlocking
import org.apache.commons.text.StringEscapeUtils
import splitties.init.appCtx
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.CancellationException
import java.util.regex.Pattern
import androidx.core.net.toUri
import kotlinx.coroutines.currentCoroutineContext

internal fun isMissingLocalBookFile(
    isContentUri: Boolean,
    localFileExists: Boolean,
    error: Throwable,
): Boolean {
    if (error is SecurityException || error is CancellationException) return false
    return if (isContentUri) {
        error is FileNotFoundException ||
                error is IllegalArgumentException &&
                error.message?.contains(FileNotFoundException::class.java.name) == true
    } else {
        !localFileExists
    }
}

internal fun findExactRemoteBook(
    remoteBooks: List<RemoteBook>,
    fileName: String,
): RemoteBook? = remoteBooks.firstOrNull { !it.isDir && it.filename == fileName }

internal fun resolveLocalBookOutputFile(root: File, relativePath: String): File {
    val canonicalRoot = root.canonicalFile
    val outputFile = File(canonicalRoot, relativePath).canonicalFile
    if (!outputFile.toPath().startsWith(canonicalRoot.toPath())) {
        throw SecurityException("书籍文件只能保存到指定路径")
    }
    return outputFile
}

internal fun prepareLocalBookOutputFile(root: File, relativePath: String): File {
    var outputFile = resolveLocalBookOutputFile(root, relativePath)
    val parent = outputFile.parentFile
    if (parent != null && !parent.exists() && !parent.mkdirs()) {
        throw FileNotFoundException("Unable to create book directory: $parent")
    }
    outputFile = resolveLocalBookOutputFile(root, relativePath)
    return outputFile
}

/**
 * 书籍文件导入 目录正文解析
 * 支持在线文件(txt epub umd 压缩文件 本地文件
 */
object LocalBook {

    private val nameAuthorPatterns = arrayOf(
        Pattern.compile("(.*?)《([^《》]+)》.*?作者：(.*)"),
        Pattern.compile("(.*?)《([^《》]+)》(.*)"),
        Pattern.compile("(^)(.+) 作者：(.+)$"),
        Pattern.compile("(^)(.+) by (.+)$")
    )

    @Throws(FileNotFoundException::class, SecurityException::class)
    fun getBookInputStream(book: Book): InputStream {
        val uri = book.getLocalUri()
        val inputStreamResult = uri.inputStream(appCtx)
        inputStreamResult.getOrNull()?.let { return it }
        val readError = inputStreamResult.exceptionOrNull()
            ?: FileNotFoundException("${uri.path} 文件不存在")
        if (!isMissingLocalBookFile(
                isContentUri = uri.isContentScheme(),
                localFileExists = uri.path?.let(::File)?.exists() == true,
                error = readError,
            )
        ) {
            throw readError
        }
        book.removeLocalUriCache()
        val localArchiveUri = book.getArchiveUri()
        if (localArchiveUri != null) {
            restoreArchiveBookFile(book, localArchiveUri)
            return getBookInputStream(book)
        }
        if (downloadRemoteBook(book)) {
            return getBookInputStream(book)
        }
        throw FileNotFoundException("${uri.path} 文件不存在").apply {
            addSuppressed(readError)
        }
    }

    fun getLastModified(book: Book): Result<Long> {
        return kotlin.runCatching {
            val uri = book.getLocalUri()
            val fileDoc = FileDoc.fromUri(uri, false)
            if (fileDoc.exists()) {
                return@runCatching fileDoc.lastModified
            }
            throw FileNotFoundException("${uri.path} 文件不存在")
        }
    }

    @Throws(TocEmptyException::class)
    fun getChapterList(book: Book): ArrayList<BookChapter> {
        val chapters = when {
            book.isEpub -> {
                EpubFile.getChapterList(book)
            }

            book.isUmd -> {
                UmdFile.getChapterList(book)
            }

            book.isPdf -> {
                PdfFile.getChapterList(book)
            }

            book.isMobi -> {
                MobiFile.getChapterList(book)
            }

            else -> {
                TextFile.getChapterList(book)
            }
        }
        if (chapters.isEmpty()) {
            throw TocEmptyException(appCtx.getString(R.string.chapter_list_empty))
        }
        val list = ArrayList(LinkedHashSet(chapters))
        list.forEachIndexed { index, bookChapter ->
            bookChapter.index = index
            if (bookChapter.title.isEmpty()) {
                bookChapter.title = "无标题章节"
            }
        }
        val replaceRules = ContentProcessor.get(book).getTitleReplaceRules()
        val replaceBook = book.toReplaceBook()
        book.durChapterTitle = list.getOrElse(book.durChapterIndex) { list.last() }
            .getDisplayTitle(
                replaceRules,
                book.getUseReplaceRule(),
                replaceBook = replaceBook
            )
        book.latestChapterTitle =
            list.getOrElse(book.simulatedTotalChapterNum() - 1) { list.last() }
                .getDisplayTitle(
                    replaceRules,
                    book.getUseReplaceRule(),
                    replaceBook = replaceBook
                )
        book.totalChapterNum = list.size
        book.latestChapterTime = System.currentTimeMillis()
        return list
    }

    fun getContent(book: Book, chapter: BookChapter): String? {
        var content = try {
            when {
                book.isEpub -> {
                    EpubFile.getContent(book, chapter)
                }

                book.isUmd -> {
                    UmdFile.getContent(book, chapter)
                }

                book.isPdf -> {
                    PdfFile.getContent(book, chapter)
                }

                book.isMobi -> {
                    MobiFile.getContent(book, chapter)
                }

                else -> {
                    TextFile.getContent(book, chapter)
                }
            }
        } catch (e: Exception) {
            e.printOnDebug()
            AppLog.put("获取本地书籍内容失败\n${e.localizedMessage}", e)
            "获取本地书籍内容失败\n${e.localizedMessage}"
        }
        if (book.isEpub) {
            content ?: return null
            if (content.indexOf('&') > -1) {
                content = content.replace("&lt;img", "&lt; img", true)
                return StringEscapeUtils.unescapeHtml4(content)
            }
        }

        if (content.isNullOrEmpty() && !chapter.isVolume) {
            return null
        }

        return content
    }

    fun getCoverPath(book: Book): String {
        return getCoverPath(book.bookUrl)
    }

    private fun getCoverPath(bookUrl: String): String {
        return FileUtils.getPath(
            appCtx.externalFiles,
            "covers",
            "${MD5Utils.md5Encode16(bookUrl)}.jpg"
        )
    }

    /**
     * 下载在线的文件并自动导入到阅读（txt umd epub)
     */
    suspend fun importFileOnLine(
        str: String,
        fileName: String,
        source: BaseSource? = null,
    ): Book {
        return importFile(saveBookFile(str, fileName, source))
    }

    /**
     * 导入本地文件
     */
    fun importFile(uri: Uri): Book {
        val bookUrl: String
        //updateTime变量不要修改,否则会导致读取不到缓存
        val (fileName, _, _, updateTime, _) = FileDoc.fromUri(uri, false).apply {
            if (size == 0L) throw EmptyFileException("Unexpected empty File")

            bookUrl = toString()
        }
        var book = appDb.bookDao.getBook(bookUrl)
        if (book == null) {
            val nameAuthor = analyzeNameAuthor(fileName)
            book = Book(
                type = BookType.text or BookType.local,
                bookUrl = bookUrl,
                name = nameAuthor.first,
                author = nameAuthor.second,
                originName = fileName,
                latestChapterTime = updateTime,
                order = appDb.bookDao.minOrder - 1
            )
            upBookInfo(book)
            appDb.bookDao.insert(book)
        } else {
            withParserCacheInvalidated(book) {
                deleteBook(book, false)
                upBookInfo(book)
                // 触发 isLocalModified
                book.latestChapterTime = 0
                //已有书籍说明是更新,删除原有目录
                appDb.bookChapterDao.delByBook(bookUrl)
            }
        }
        return book
    }

    fun upBookInfo(book: Book) {
        when {
            book.isEpub -> EpubFile.upBookInfo(book)
            book.isUmd -> UmdFile.upBookInfo(book)
            book.isPdf -> PdfFile.upBookInfo(book)
            book.isMobi -> MobiFile.upBookInfo(book)
        }
    }

    fun <T> withParserCacheInvalidated(
        uri: Uri,
        fileName: String,
        action: () -> T,
    ): T {
        return withParserCacheInvalidated(
            FileDoc.fromUri(uri, false).toString(),
            fileName,
            action,
        )
    }

    internal fun <T> withParserCacheInvalidated(book: Book, action: () -> T): T {
        return withParserCacheInvalidated(book.bookUrl, book.originName, action)
    }

    internal fun <T> withParserCacheInvalidated(
        bookUrl: String,
        fileName: String,
        action: () -> T,
    ): T {
        return when {
            fileName.endsWith(".epub", true) -> synchronized(EpubFile) {
                EpubFile.clear(bookUrl)
                action()
            }

            fileName.endsWith(".umd", true) -> synchronized(UmdFile) {
                UmdFile.clear(bookUrl)
                action()
            }

            fileName.endsWith(".pdf", true) -> synchronized(PdfFile) {
                PdfFile.clear(bookUrl)
                action()
            }

            fileName.endsWith(".mobi", true) ||
                fileName.endsWith(".azw3", true) ||
                fileName.endsWith(".azw", true) -> synchronized(MobiFile) {
                MobiFile.clear(bookUrl)
                action()
            }

            else -> action()
        }
    }

    /* 导入压缩包内的书籍 */
    fun importArchiveFile(
        archiveFileUri: Uri,
        saveFileName: String? = null,
        filter: ((String) -> Boolean)? = null
    ): List<Book> {
        val archiveFileDoc = FileDoc.fromUri(archiveFileUri, false)
        val files = ArchiveUtils.deCompress(archiveFileDoc, filter = filter)
        if (files.isEmpty()) {
            throw NoStackTraceException(appCtx.getString(R.string.unsupport_archivefile_entry))
        }
        return files.map {
            saveBookFile(FileInputStream(it), saveFileName ?: it.name).let { uri ->
                importFile(uri).apply {
                    //附加压缩包名称 以便解压文件被删后再解压
                    origin = "${BookType.localTag}::${archiveFileDoc.name}"
                    addType(BookType.archive)
                    save()
                }
            }
        }
    }

    /* 批量导入 支持自动导入压缩包的支持书籍 */
    fun importFiles(uri: Uri): List<Book> {
        val books = mutableListOf<Book>()
        val fileDoc = FileDoc.fromUri(uri, false)
        if (ArchiveUtils.isArchive(fileDoc.name)) {
            books.addAll(
                importArchiveFile(uri) {
                    it.matches(AppPattern.bookFileRegex)
                }
            )
        } else {
            books.add(importFile(uri))
        }
        return books
    }

    fun importFiles(uris: List<Uri>) {
        var errorCount = 0
        uris.forEach { uri ->
            val fileDoc = FileDoc.fromUri(uri, false)
            kotlin.runCatching {
                if (ArchiveUtils.isArchive(fileDoc.name)) {
                    importArchiveFile(uri) {
                        it.matches(AppPattern.bookFileRegex)
                    }
                } else {
                    importFile(uri)
                }
            }.onFailure {
                AppLog.put("ImportFile Error:\nFile $fileDoc\n${it.localizedMessage}", it)
                errorCount += 1
            }
        }
        if (errorCount == uris.size) {
            throw NoStackTraceException("ImportFiles Error:\nAll input files occur error")
        }
    }

    /**
     * 从文件分析书籍必要信息（书名 作者等）
     */
    private fun analyzeNameAuthor(fileName: String): Pair<String, String> {
        val tempFileName = fileName.substringBeforeLast(".")
        var name = ""
        var author = ""
        if (!AppConfig.bookImportFileName.isNullOrBlank()) {
            try {
                //在用户脚本后添加捕获author、name的代码，只要脚本中author、name有值就会被捕获
                val js =
                    AppConfig.bookImportFileName + "\nJSON.stringify({author:author,name:name})"
                //在脚本中定义如何分解文件名成书名、作者名
                val jsonStr = RhinoScriptEngine.run {
                    val bindings = ScriptBindings()
                    bindings["src"] = tempFileName
                    eval(js, bindings)
                }.toString()
                val bookMess = GSON.fromJsonObject<HashMap<String, String>>(jsonStr)
                    .getOrThrow()
                name = bookMess["name"] ?: ""
                author = bookMess["author"]?.takeIf { it.length != tempFileName.length } ?: ""
            } catch (e: Exception) {
                AppLog.put("执行导入文件名规则出错\n${e.localizedMessage}", e)
            }
        }
        if (name.isBlank()) {
            for (pattern in nameAuthorPatterns) {
                pattern.matcher(tempFileName).takeIf { it.find() }?.run {
                    name = group(2)!!
                    val group1 = group(1) ?: ""
                    val group3 = group(3) ?: ""
                    author = BookHelp.formatBookAuthor(group1 + group3)
                    return Pair(name, author)
                }
            }
            name = BookHelp.formatBookName(tempFileName)
            author = BookHelp.formatBookAuthor(tempFileName.replace(name, ""))
                .takeIf { it.length != tempFileName.length } ?: ""
        }
        return Pair(name, author)
    }

    fun deleteBook(book: Book, deleteOriginal: Boolean) {
        kotlin.runCatching {
            BookHelp.clearCache(book)
            if (!book.coverUrl.isNullOrEmpty()) {
                FileUtils.delete(book.coverUrl!!)
            }
            if (deleteOriginal) {
                FileDoc.fromUri(book.getLocalUri(), false).delete()
            }
        }
    }

    /**
     * 下载在线的文件
     */
    suspend fun saveBookFile(
        str: String,
        fileName: String,
        source: BaseSource? = null,
    ): Uri {
        AppConfig.defaultBookTreeUri
            ?: throw NoBooksDirException()
        val inputStream = when {
            str.isAbsUrl() -> AnalyzeUrl(
                str, source = source, callTimeout = 0,
                coroutineContext = currentCoroutineContext()
            ).getInputStreamAwait()

            str.isDataUrl() -> ByteArrayInputStream(
                Base64.decode(
                    str.substringAfter("base64,"),
                    Base64.DEFAULT
                )
            )

            else -> throw NoStackTraceException("在线导入书籍支持http/https/DataURL")
        }
        return saveBookFile(inputStream, fileName)
    }

    @Throws(SecurityException::class)
    fun saveBookFile(
        inputStream: InputStream,
        fileName: String
    ): Uri {
        inputStream.use {
            val defaultBookTreeUri = AppConfig.defaultBookTreeUri
            if (defaultBookTreeUri.isNullOrBlank()) throw NoBooksDirException()
            val treeUri = defaultBookTreeUri.toUri()
            return if (treeUri.isContentScheme()) {
                val treeDoc = DocumentFile.fromTreeUri(appCtx, treeUri)
                var doc = treeDoc!!.findFile(fileName)
                if (doc == null) {
                    doc = treeDoc.createFile(
                        FileUtils.getMimeType(fileName),
                        fileName
                    )
                        ?: throw SecurityException("请重新设置书籍保存位置\nPermission Denial")
                }
                withParserCacheInvalidated(doc.uri, fileName) {
                    appCtx.contentResolver.openOutputStream(doc.uri)!!.use { oStream ->
                        it.copyTo(oStream)
                    }
                }
                doc.uri
            } else {
                try {
                    val treeFile = File(treeUri.path!!)
                    val file = prepareLocalBookOutputFile(treeFile, fileName)
                    withParserCacheInvalidated(Uri.fromFile(file), fileName) {
                        FileOutputStream(file).use { oStream ->
                            it.copyTo(oStream)
                        }
                    }
                    Uri.fromFile(file)
                } catch (e: FileNotFoundException) {
                    throw SecurityException("请重新设置书籍保存位置\nPermission Denial\n$e").apply {
                        addSuppressed(e)
                    }
                }
            }
        }
    }

    fun isOnBookShelf(
        fileName: String
    ): Boolean {
        return appDb.bookDao.hasFile(fileName)
    }

    private fun restoreArchiveBookFile(book: Book, archiveUri: Uri) {
        val archiveFileDoc = FileDoc.fromUri(archiveUri, false)
        val extractedFile = ArchiveUtils.deCompress(
            archiveFileDoc,
            filter = { it.contains(book.originName) }
        ).firstOrNull()
            ?: throw NoStackTraceException(appCtx.getString(R.string.unsupport_archivefile_entry))
        val fileUri = saveBookFile(FileInputStream(extractedFile), book.originName)
        withParserCacheInvalidated(book) {
            book.cacheLocalUri(fileUri)
        }
    }

    //文件类书源 合并在线书籍信息 在线 > 本地
    fun mergeBook(localBook: Book, onLineBook: Book?): Book {
        onLineBook ?: return localBook
        localBook.name = onLineBook.name.ifBlank { localBook.name }
        localBook.author = onLineBook.author.ifBlank { localBook.author }
        localBook.coverUrl = onLineBook.coverUrl
        localBook.intro =
            if (onLineBook.intro.isNullOrBlank()) localBook.intro else onLineBook.intro
        localBook.save()
        return localBook
    }

    // 下载 book 对应的远程文件并绑定本地路径
    internal fun downloadRemoteBook(localBook: Book): Boolean {
        val webDavUrl = localBook.getRemoteUrl()?.takeIf(String::isNotBlank)
        if (webDavUrl == null && !AppConfig.webDavBookAutoRestore) return false
        val defaultBookWebDav = if (webDavUrl == null) {
            AppWebDav.defaultBookWebDav ?: return false
        } else null
        try {
            AppConfig.defaultBookTreeUri
                ?: throw NoBooksDirException()
            val webdav = webDavUrl?.let { url ->
                // 兼容旧版链接
                kotlin.runCatching {
                    WebDav.fromPath(url)
                }.getOrElse {
                    AppWebDav.authorization?.let { WebDav(url, it) }
                        ?: throw WebDavException("Unexpected defaultBookWebDav")
                }
            } ?: defaultBookWebDav?.let { bookWebDav ->
                val fileName = if (localBook.isArchive) {
                    localBook.archiveName
                } else {
                    localBook.originName
                }
                val remoteBook = runBlocking {
                    bookWebDav.getRemoteBookList(bookWebDav.rootBookUrl)
                }.let { findExactRemoteBook(it, fileName) } ?: return false
                WebDav(remoteBook.path, bookWebDav.authorization)
            } ?: return false
            val inputStream = runBlocking {
                webdav.downloadInputStream()
            }
            inputStream.use {
                if (localBook.isArchive) {
                    val archiveUri = saveBookFile(it, localBook.archiveName)
                    restoreArchiveBookFile(localBook, archiveUri)
                } else {
                    val fileUri = saveBookFile(it, localBook.originName)
                    withParserCacheInvalidated(localBook) {
                        localBook.cacheLocalUri(fileUri)
                    }
                }
            }
            return true
        } catch (e: Exception) {
            e.printOnDebug()
            AppLog.put("自动下载webDav书籍失败", e)
            return false
        }
    }

}
