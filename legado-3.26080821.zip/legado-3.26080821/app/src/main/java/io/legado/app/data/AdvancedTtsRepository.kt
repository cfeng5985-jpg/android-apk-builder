package io.legado.app.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import io.legado.app.data.entities.AdvancedTtsConfig

/**
 * 高级 TTS 引擎配置的存储仓库（SharedPreferences）
 */
class AdvancedTtsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("advanced_tts_prefs", Context.MODE_PRIVATE)

    private val gson = Gson()
    private val configsKey = "configs_list"

    /**
     * 保存配置（新增或更新）
     */
    fun saveConfig(config: AdvancedTtsConfig) {
        val list = getAllConfigs().toMutableList()
        val existingIndex = list.indexOfFirst { it.id == config.id }
        if (existingIndex >= 0) {
            list[existingIndex] = config
        } else {
            list.add(config)
        }
        prefs.edit().putString(configsKey, gson.toJson(list)).apply()
    }

    /**
     * 获取所有配置
     */
    fun getAllConfigs(): List<AdvancedTtsConfig> {
        val json = prefs.getString(configsKey, null)
        return if (json.isNullOrEmpty()) {
            emptyList()
        } else {
            try {
                val type = object : TypeToken<List<AdvancedTtsConfig>>() {}.type
                gson.fromJson(json, type) ?: emptyList()
            } catch (e: Exception) {
                // 解析失败时清空旧数据
                prefs.edit().remove(configsKey).apply()
                emptyList()
            }
        }
    }

    /**
     * 根据ID获取单个配置
     */
    fun getConfigById(id: String): AdvancedTtsConfig? {
        return getAllConfigs().firstOrNull { it.id == id }
    }

    /**
     * 删除配置
     */
    fun deleteConfig(id: String) {
        val list = getAllConfigs().toMutableList()
        list.removeAll { it.id == id }
        prefs.edit().putString(configsKey, gson.toJson(list)).apply()
    }

    /**
     * 清空所有配置（慎用）
     */
    fun clearAll() {
        prefs.edit().remove(configsKey).apply()
    }
}
